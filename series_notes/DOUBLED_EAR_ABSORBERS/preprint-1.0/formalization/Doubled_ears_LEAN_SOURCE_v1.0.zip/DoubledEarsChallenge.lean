/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
-/
module

public import PartitionedTriangleAbsorption.SignedCertificate.DoubledEarsData
public import Mathlib.Order.Bounds.Defs

@[expose] public section

namespace PartitionedTriangleAbsorption

open Finset

variable {V : Type*} [DecidableEq V] {t : ℕ}

def triEdges (s : Finset V) : Finset (Sym2 V) := s.sym2.filter (fun e => ¬ e.IsDiag)

def IsTypedTri (p : V → Fin t) (F : Finset (Multiset (Fin t))) (s : Finset V) : Prop :=
  s.card = 3 ∧ s.val.map p ∈ F

def IsDecomp (p : V → Fin t) (F : Finset (Multiset (Fin t))) (E : Finset (Sym2 V))
    (D : Finset (Finset V)) : Prop :=
  (∀ s ∈ D, IsTypedTri p F s) ∧ (D : Set (Finset V)).PairwiseDisjoint triEdges ∧
    D.biUnion triEdges = E

def HasDecomp (p : V → Fin t) (F : Finset (Multiset (Fin t))) (E : Finset (Sym2 V)) : Prop :=
  ∃ D, IsDecomp p F E D

end PartitionedTriangleAbsorption

namespace PartitionedTriangleAbsorption.TypedApplicationLinks

open Finset

def F0 : Finset (Multiset (Fin 2)) := {{0, 0, 1}, {0, 1, 1}}

end PartitionedTriangleAbsorption.TypedApplicationLinks

namespace PartitionedTriangleAbsorption.SignedCertificate

open Finset TypedApplicationLinks

variable {V : Type*} [DecidableEq V]

def IsAbsorber (p : V → Fin 2) (P A : Finset (Sym2 V)) : Prop :=
  Disjoint A P ∧ HasDecomp p F0 A ∧ HasDecomp p F0 (A ∪ P)

def IsTwoMode (p : V → Fin 2) (P A Q : Finset (Sym2 V)) : Prop :=
  Disjoint P A ∧ Disjoint P Q ∧ Disjoint A Q ∧ HasDecomp p F0 Q ∧
    HasDecomp p F0 (A ∪ P) ∧ HasDecomp p F0 (A ∪ Q)

end PartitionedTriangleAbsorption.SignedCertificate

namespace PartitionedTriangleAbsorption.SignedCertificate.DoubledEarEquality

open Finset TypedApplicationLinks

variable {V : Type*} [DecidableEq V]

def unionEdges (D : Finset (Finset V)) : Finset (Sym2 V) := D.biUnion triEdges

/-- The incidence form of the routing data. The negative packing assigns
auxiliaries to core edges and closes split ears. In the positive packing,
the shared non-source inventory permutes the spokes and decomposes the
auxiliary graph. -/
def HasRoutingModes (p : V → Fin 2) (r : V → Fin 3)
    (H C P : Finset (Sym2 V)) : Prop :=
  ∃ D N : Finset (Finset V),
    IsDecomp p F0 (unionEdges D) D ∧ IsDecomp p F0 (unionEdges N) N ∧
    unionEdges D ⊆ H ∧
    (∀ t ∈ D, Positive r t) ∧ (∀ t ∈ N, Negative r t) ∧
    (unionEdges N).filter (centre r) = C ∧
    (unionEdges D).filter (rim r) = P ∧
    (unionEdges D).filter (fun e => ¬ rim r e) = unionEdges N

theorem core_sensitive_bound (p : V → Fin 2) (r : V → Fin 3)
    (A P : Finset (Sym2 V)) (habs : IsAbsorber p P A)
    (hP : ∀ e ∈ P, rim r e)
    (hA : ∀ e ∈ A, ¬ rim r e ∧ e.map r ≠ s(1,1))
    (m : ℕ) (hsize : P.card = 4 * m) :
    12 * m ≤ A.card + 6 * (A.filter (centre r)).card := by
  sorry

theorem protected_centres_bound (p : V → Fin 2) (r : V → Fin 3)
    (A P : Finset (Sym2 V)) (habs : IsAbsorber p P A)
    (hP : ∀ e ∈ P, rim r e)
    (hA : ∀ e ∈ A, ¬ rim r e ∧ e.map r ≠ s(1,1))
    (Z : Set V) (hZ : ∀ x, r x = 0 → x ∈ Z)
    (hProtect : ∀ x y, s(x,y) ∈ A → ¬ (x ∈ Z ∧ y ∈ Z))
    (m : ℕ) (hsize : P.card = 4 * m) : 12 * m ≤ A.card := by
  sorry

theorem optimum_iff_routing_modes (p : V → Fin 2) (r : V → Fin 3)
    (H C P : Finset (Sym2 V))
    (hP : ∀ e ∈ P, rim r e) (hPH : P ⊆ H)
    (hH : ∀ e ∈ H, e.map r ≠ s(1,1) ∧
      (rim r e → e ∈ P) ∧ (centre r e → e ∈ C))
    (hsize : P.card = 4 * C.card) :
    (∃ A, A ⊆ H ∧ IsAbsorber p P A ∧ A.card = 6 * C.card) ↔ HasRoutingModes p r H C P := by
  sorry

theorem twoMode_of_routing_modes (p : V → Fin 2) (r : V → Fin 3)
    (H C P Q : Finset (Sym2 V)) (hP : ∀ e ∈ P, rim r e) (hPH : P ⊆ H)
    (hH : ∀ e ∈ H, e.map r ≠ s(1,1) ∧
      (rim r e → e ∈ P) ∧ (centre r e → e ∈ C))
    (hsize : P.card = 4 * C.card) (hr : HasRoutingModes p r H C P)
    (hQ : HasDecomp p F0 Q) (hQH : Disjoint Q H) :
    ∃ A, A ⊆ H ∧ IsTwoMode p P A Q ∧ A.card = 6 * C.card := by
  sorry

end PartitionedTriangleAbsorption.SignedCertificate.DoubledEarEquality

namespace PartitionedTriangleAbsorption.SignedCertificate.TriangleFreeCore

open Finset TypedApplicationLinks

theorem minimum_path_absorber :
    IsLeast {n : ℕ | ∃ A : Finset (Sym2 (Fin 13)), A ⊆ allowed ∧
      IsAbsorber part source A ∧ A.card = n} (6 * core.card) := by
  sorry

end PartitionedTriangleAbsorption.SignedCertificate.TriangleFreeCore

namespace PartitionedTriangleAbsorption.SignedCertificate.LabelledPathMinimum

open Finset TypedApplicationLinks

theorem minimum_labelled_path_absorber :
    IsLeast {n : ℕ | ∃ A : Finset (Sym2 (Fin 14)), A ⊆ allowed ∧
      IsAbsorber part source A ∧ A.card = n} 21 := by
  sorry

end PartitionedTriangleAbsorption.SignedCertificate.LabelledPathMinimum

namespace PartitionedTriangleAbsorption.SignedCertificate.SubdividedClawMinimum

open Finset TypedApplicationLinks

theorem minimum_subdivided_claw_absorber :
    IsLeast {n : ℕ | ∃ A : Finset (Sym2 (Fin 24)), A ⊆ allowed ∧
      IsAbsorber part source A ∧ A.card = n} 36 := by
  sorry

theorem no_connected_triple_partition :
    ¬ ∃ S T : Finset (Fin 6), S.card = 3 ∧ T.card = 3 ∧
      S ∪ T = univ ∧ noIsolated S ∧ noIsolated T := by
  sorry

end PartitionedTriangleAbsorption.SignedCertificate.SubdividedClawMinimum

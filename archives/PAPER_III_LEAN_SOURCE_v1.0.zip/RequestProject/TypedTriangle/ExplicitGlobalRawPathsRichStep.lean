/-
Copyright (c) 2026 Juan Pablo Traverso Gianini.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
module
public import RequestProject.TypedTriangle.VortexGlobalGeometryBudget
public import RequestProject.TypedTriangle.ExplicitAutomaticNativePaths
@[expose] public section

open Finset Classical S07V24
noncomputable section
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
namespace TypedTriangle.Vortex.ExplicitRaw
open S07V25 ComponentRows

def globalRawStepOrder (α C q : ℝ) (h M : ℕ) : ℝ :=
  max (max (nativeSampleOrder (α/2) q (2*C) h) ((8*((h:ℝ)+1))^4))
    (max (2*(M:ℝ)/q) 1)

/-- Uniform clean sampling with the intrinsic global-index debt held fixed
through the geometric step. -/
theorem global_clean_raw_paths_rich_step_explicit (α₀ C D : ℝ) (h : ℕ)
    (hα : 0 < α₀) (hh : 1 ≤ h) (hC : 0 < C) (hD : 0 ≤ D) :
    ∀ q : ℝ, 0 < q → q ≤ 1 / 32 →
      ∀ M L : ℕ, ∀ β : ℕ → ℝ, 1 ≤ M → (∀ j, 0 ≤ β j) →
      D * (∑ j ∈ range (L + 1), β j) ≤ α₀ / 4 →
      let m := nativeInteriorCount (α₀/2) h;
      let a := nativeDensity (α₀/2) h;
      let εRoute := nativeRoutePrecision (α₀/2) q h;
      ∀ {V I : Type} [Fintype V]
      (H : Host V I) (F : Set (Multiset I)) (r : ℕ), r ≤ L →
      globalRawStepOrder α₀ C q h M ≤ (Fintype.card V : ℝ) →
      CommonNbrCond H F (globalGeometryFloor α₀ h D β (Fintype.card V) r) →
      CleanHingeCond H F (globalGeometryFloor α₀ h D β (Fintype.card V) r) h →
      ∀ ε : ℝ, ε ≤ 1 / 2 → ∀ μ : Finset V → ℝ,
        (∀ T, IsAllowed H F T → 0 ≤ μ T ∧ μ T ≤ (2 * C) / Fintype.card V) →
        (∀ e ∈ edges H, |bdry H F μ e - 1| ≤ ε) →
      let η := automaticRelativeError (Fintype.card V)
      0 < η ∧ η < 1 ∧ ∃ W : Finset V, M ≤ W.card ∧ 16 * W.card ≤ Fintype.card V ∧
        CommonNbrCond (restrictedHost H (univ \ W)) F (globalGeometryFloor α₀ h D β W.card r) ∧
        CleanHingeCond (restrictedHost H (univ \ W)) F (globalGeometryFloor α₀ h D β W.card r) h ∧
        ((1 - η) * q * Fintype.card V ≤ W.card ∧
          (W.card : ℝ) < (1 + η) * q * Fintype.card V) ∧
        (∀ u v, H.G.Adj u v →
          |S07V48.sampW H.G H.lab F μ W u v / q - 1| ≤ ε + 2 * η) ∧
        S07V27.RouteProp H.G H.lab F (m + 1) εRoute W ∧
        (∀ v x y, AdmPair (activeComps H.G H.lab F)
          (fun v C => IsBip H.G H.lab F (v,C)) (colG H.G H.lab F) v x y →
          a * (Fintype.card V : ℝ)^m * q^m / 2 ≤
            (pathsIn (link H.G H.lab F v) m x y W).card) ∧
        (∀ u v, u ≠ v → ∀ k, ({H.lab u,H.lab v,k} : Multiset I) ∈ F →
          α₀ * q * Fintype.card V / 4 ≤ ((commonNbrs H k u v) ∩ W).card) ∧
        ∀ U : Finset V, W ⊆ U →
          CommonNbrCond (restrictedHost H (univ \ U)) F (α₀ * q ^ h / 4) ∧
          HingeCond (restrictedHost H (univ \ U)) F (α₀ * q ^ h / 4) h := by
  intro q hq hq32 M L β hM hβ hDebt
  dsimp only
  have hq1 : q ≤ 1 := by linarith
  let m := nativeInteriorCount (α₀/2) h
  let a := nativeDensity (α₀/2) h
  let εRoute := nativeRoutePrecision (α₀/2) q h
  let Ns := nativeSampleOrder (α₀/2) q (2*C) h
  have hSample {V I : Type} [Fintype V] := automatic_native_clean_raw_paths_explicit (α₀/2) (2*C) h
    (by positivity) (by positivity) q hq hq1 (V := V) (I := I)
  let B : ℝ := 8 * ((h : ℝ) + 1)
  let N := globalRawStepOrder α₀ C q h M
  have hN1 : 1 ≤ N := (le_max_right _ _).trans (le_max_right _ _)
  intro V I _ H F r hr hn h3 hClean ε hε μ hμ hLoad
  let n : ℝ := Fintype.card V
  have hnpos : 0 < n := lt_of_lt_of_le zero_lt_one (hN1.trans hn)
  have hnSample : Ns ≤ n := ((le_max_left _ _).trans (le_max_left _ _)).trans hn
  have hnPower : B ^ 4 ≤ n := ((le_max_right _ _).trans (le_max_left _ _)).trans hn
  have hnScale : 2 * (M : ℝ) / q ≤ n :=
    ((le_max_left _ _).trans (le_max_right _ _)).trans hn
  have hPrefix : (∑ j ∈ range r, β j) ≤ ∑ j ∈ range (L + 1), β j :=
    sum_le_sum_of_subset_of_nonneg (range_mono (by omega)) (by intro j _ _; exact hβ j)
  have hDebtPrefix : D * (∑ j ∈ range r, β j) ≤ α₀ / 4 :=
    (mul_le_mul_of_nonneg_left hPrefix hD).trans hDebt
  have hαFloor : α₀ / 2 ≤ globalGeometryFloor α₀ h D β n r :=
    globalGeometryFloor_half_le α₀ D h β n r hα.le hnPower hDebtPrefix
  have hαPos : 0 < globalGeometryFloor α₀ h D β n r := lt_of_lt_of_le (by positivity) hαFloor
  obtain ⟨hηpos, hηlt, W, hWlo, hWhi, hpool, hhinge, hProfile, hRoute, hPaths⟩ :=
    hSample H F (globalGeometryFloor α₀ h D β n r) ε hαFloor hε hnSample h3
      hClean.hingeCond hClean μ hμ hLoad
  have hB : 0 < B := by dsimp [B]; positivity
  have hErr := automaticRelativeError_le_of_power_bound B n hB hnPower
  have hTwoB : (2 : ℝ) ≤ B := by dsimp [B]; nlinarith [(Nat.cast_nonneg h : (0 : ℝ) ≤ (h : ℝ))]
  have hηhalf : automaticRelativeError n ≤ 1 / 2 := by
    have hInv := one_div_le_one_div_of_le (by norm_num : (0 : ℝ) < 2) hTwoB
    exact hErr.trans (by simpa only [one_div] using hInv)
  change (1 - automaticRelativeError n) * q * n ≤ (W.card : ℝ) at hWlo
  change (W.card : ℝ) < (1 + automaticRelativeError n) * q * n at hWhi
  have hMReal : (M : ℝ) ≤ W.card := by
    have hscale := (div_le_iff₀ hq).mp hnScale
    have hhalf : (1 / 2 : ℝ) ≤ 1 - automaticRelativeError n := by linarith
    have hmul := mul_le_mul_of_nonneg_right hhalf (mul_nonneg hq.le hnpos.le)
    nlinarith [hWlo]
  have hMW : M ≤ W.card := by exact_mod_cast hMReal
  have hWpos : 0 < W.card := lt_of_lt_of_le zero_lt_one (hM.trans hMW)
  have hWposR : (0 : ℝ) < W.card := by exact_mod_cast hWpos
  have hUpper : (W.card : ℝ) ≤ (2 * q) * n := by
    calc
      _ ≤ (1 + automaticRelativeError n) * q * n := hWhi.le
      _ ≤ (2 * q) * n := by gcongr; linarith
  have hqScale : 16 * (2 * q) ≤ 1 := by linarith
  have h16 : 16 * (W.card : ℝ) ≤ n := by
    have hmul := mul_le_mul_of_nonneg_right hqScale hnpos.le
    nlinarith [hUpper]
  have h16N : 16 * W.card ≤ Fintype.card V := by
    change 16 * (W.card : ℝ) ≤ (Fintype.card V : ℝ) at h16
    exact_mod_cast h16
  have hGeo := clean_relative_sample_child_geometry H F hαPos hq
    hηpos.le hηlt hh hClean W hWhi.le hpool hhinge
  have hFloorStep := globalGeometryFloor_sample α₀ D h β hα.le hD hβ
    n W.card r r hnpos hWposR h16 le_rfl
  have hFirst : globalGeometryFloor α₀ h D β n r / 2 ≤
      (1 - automaticRelativeError n) * globalGeometryFloor α₀ h D β n r := by
    have hmul := mul_le_mul_of_nonneg_right hηhalf hαPos.le
    nlinarith
  have hBase : α₀ / 4 ≤ (1 - automaticRelativeError n) * globalGeometryFloor α₀ h D β n r := by
    linarith
  refine ⟨hηpos, hηlt, W, hMW, h16N, commonNbrCond_mono hGeo.1 hFloorStep,
    hGeo.2.mono hFloorStep, ⟨hWlo, hWhi⟩, hProfile, hRoute, hPaths, ?_, ?_⟩
  · intro u v huv k hk
    have hp := hpool u v huv k hk
    have hs := mul_le_mul_of_nonneg_right hBase (mul_nonneg hq.le hnpos.le)
    calc
      α₀ * q * Fintype.card V / 4 = (α₀ / 4) * (q * n) := by ring
      _ ≤ (1 - automaticRelativeError n) * globalGeometryFloor α₀ h D β n r * (q * n) := hs
      _ = (1 - automaticRelativeError n) * globalGeometryFloor α₀ h D β n r * q * n := by ring
      _ ≤ _ := hp
  · intro U hWU
    have hInter := anchored_clean_intermediate_geometry H F hαPos hq hq1 hηlt hh
      hClean W U hWU hpool hhinge
    have hScaled := mul_le_mul_of_nonneg_right hBase (pow_nonneg hq.le h)
    have hCoeff : α₀ * q ^ h / 4 ≤
        (1 - automaticRelativeError n) * globalGeometryFloor α₀ h D β n r * q ^ h := by
      convert hScaled using 1 <;> ring
    exact ⟨commonNbrCond_mono hInter.1 hCoeff, hingeCond_mono hInter.2.hingeCond hCoeff⟩


#print axioms global_clean_raw_paths_rich_step_explicit
end TypedTriangle.Vortex.ExplicitRaw

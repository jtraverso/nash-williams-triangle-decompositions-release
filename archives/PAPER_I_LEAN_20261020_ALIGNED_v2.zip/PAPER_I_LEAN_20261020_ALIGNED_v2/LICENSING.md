# Licence restoration — aligned Paper I freeze v2

Copyright (c) 2026 Juan Pablo Traverso Gianini.

The author's original packaging scripts and materials are licensed under
Apache-2.0, supplied in `LICENSE`. Existing source copyright and licence notices
remain in force. `source/LICENSE` restores the Apache-2.0 text from the original
Paper II freeze, including for the 62 unchanged sources that refer to that file.
This addition does not replace individual third-party terms.

The nine original dependency licence files are restored byte-for-byte under
`dependencies/licenses/`: Mathlib, aesop, batteries, importGraph,
LeanSearchClient, plausible, proofwidgets and Qq use their supplied Apache-2.0
texts; Cli retains its supplied MIT licence and copyright notice. The dependency
revisions are unchanged in `evidence/environment.json` and
`source/lake-manifest.json`. These texts were identical in the two original
source freezes. No dependency source or compiled objects are added.

This archive is `PAPER_I_LEAN_20261020_ALIGNED_v2`. It adds licence files and this notice to `PAPER_I_LEAN_20261020_ALIGNED_v1`
(SHA-256 `7cc2b21543c2b76b0f4401c711d636adf19da4d1c2d173d153b6a8ec88fd585f`). Every pre-existing file remains byte-identical except
`SHA256SUMS.txt`, which is regenerated to include the additions. In particular,
all 1,070 Lean sources, build configuration, scripts, receipts, compiler logs,
verification records and the historical README retain their original bytes.
Any v1 identifiers in those historical records identify the original build.

This is a licence-only repackaging of the same recorded clean build, not a new
Lean compilation. The six queried declarations and their axiom evidence are
unchanged. Manuscripts are outside this archive and retain their separate rights.

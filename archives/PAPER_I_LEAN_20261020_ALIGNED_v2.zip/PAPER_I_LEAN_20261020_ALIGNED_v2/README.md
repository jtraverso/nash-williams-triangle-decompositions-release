# Paper I: aligned clean build, freeze v1

Identifier: `PAPER_I_LEAN_20261020_ALIGNED_v1` (assembled 2026-10-20 07:59 UTC).

This freeze records a complete compilation of the Paper I closure from source. Every one of
the 1070 project modules of the closure of `RequestProject.NW18.AuditPaperIIAssembly` was compiled by the pinned
toolchain during this build campaign, starting from an empty project output directory; no project
object from an earlier build was reused. The final audit module reports
`PASS_PAPERII_PROOF_DEPENDENCIES`, and its six axiom queries list only `propext`,
`Classical.choice` and `Quot.sound`. No module log contains a `sorry` warning.

## What was built

- **Sources:** the aligned tree described in `evidence/ALIGNMENT_MANIFEST.json`. It is built
  from `PAPER_I_LEAN_20261017_v1` and `PAPER_II_LEAN_20261019_v1`: every shared
  `PartitionedTriangleAbsorption` module takes its Paper II freeze source, Paper I-only modules
  are unchanged, `RequestProject.NW18.FourColourPaperII` is moved unchanged to
  `PartitionedTriangleAbsorption.PaperII.FourColourApplication`, and one import line of
  `RequestProject.NW18.Case128Reduction` follows that move.
- **Toolchain and dependencies:** `leanprover/lean4:v4.35.0-rc3`; Mathlib `c55e6e786f49471c72fbddbec5415808896aec1e`;
  the other package revisions are in `evidence/environment.json`. Mathlib objects were the pinned
  build products on the machine, not rebuilt.
- **Closure:** 1070 modules (the original Paper I freeze had 1,069; the moved four-colour
  module and the Paper II version of `RoutedPaper` change the closure by one module).

## Evidence

| File | Content |
|---|---|
| `evidence/receipts/` | One receipt per module: exit code, seconds, source hash, the object hash of every project import at compile time, own object hash |
| `evidence/module_logs/` | Compiler output per module, including all `#print axioms` lines |
| `evidence/final_audit.log` | Output of `RequestProject.NW18.AuditPaperIIAssembly` |
| `evidence/verification.json` | Checks run when this freeze was assembled |
| `evidence/build_plan.json` | Topological order and project imports |
| `evidence/early_module_recheck.txt` | Recompilation of the first 23 modules after the Mathlib checkout changed (see Limits) |

Verification at assembly: all 1070 receipts succeeded; each source hash equals the frozen
source; each object on disk has the recorded hash; and every recorded import hash equals that
import's own object hash, so the receipts form one consistent chain.

## Limits

- The campaign ran in several invocations of `tools/build.py` (resumed after resource tuning).
  A resumed invocation accepted only objects whose receipts this campaign wrote and whose hashes
  still matched; nothing from the original freezes' builds was reused.
- The first 23 modules were compiled against a separately downloaded Mathlib checkout of the same
  revision, which was then replaced by an existing checkout of that revision. Those modules were
  recompiled against the final checkout; `evidence/early_module_recheck.txt` records the result.
- This is a local build on one machine, not an independent reproduction by another party.
- The Paper II closure is a separate phase and is not covered by this freeze.

## Reproduction

`tools/align.py` rebuilds the aligned tree from the two source freezes; `tools/build.py paper_I`
recompiles the closure in topological order and writes receipts and logs. Install the toolchain
with elan and provide Mathlib at the pinned revision (for example `lake exe cache get`).

# Paper II — selected sources with corrected author headers

Identifier: `PAPER_II_LEAN_20261020_ALIGNED_v4`. Author: Juan Pablo Traverso Gianini.

All 1,510 Lean files carry the author's correct name and Apache-2.0 notice.
Relative to `PAPER_II_LEAN_20261020_ALIGNED_v1`, 1,352 missing headers are added, 59 surname
misspellings are corrected and 99 headers were already correct. Every byte after
the initial ordinary header comment is unchanged.

## Verification scope

No Lean/Lake compilation was run for this revision. The unchanged 1,510
receipts and fifteen final axiom-query outputs describe the sources BEFORE
the header correction. Do not compare those historical source hashes
directly to the corrected files or call this a new clean build.

`attribution/source_changes.json` binds both versions and their common
bodies. It stores the old and new prefixes, allowing the exact historical
source bytes to be reconstructed without including another source tree.
Run the following from this extracted root:

```text
python tools/verify_attribution.py
```

This verifies the current source hashes, reconstructed historical hashes,
all historical receipts and their project-import hash chain, and the
archive's internal manifest. It does not execute Lean or inspect omitted
compiled objects.

The original campaign instructions are preserved in
`evidence/BUILD_README.md`; their paths and source identities are historical.
To compile the corrected edition, use `source/` from this archive and the
pinned toolchain/dependencies, writing new receipts in a separate output.
Do not use the historical alignment script to overwrite these sources.

`source/LICENSE` covers the project sources; `LICENSE` covers original
packaging materials. Dependency notices are in `dependencies/licenses/`.
See `LICENSING.md`. The recorded clean campaign compiled 623 modules in the Paper I phase and 887 in the Paper II phase.

Revision v3 corrects this README's paper title and archive identifier only, and updates SHA256SUMS.txt. All source, licence, attribution and historical evidence bytes are identical to v2. No compilation is performed.

Revision v4 repairs UTF-8 typography in this README. References in source comments to historical research notes and candidate-generation scripts (including cegis paths) are provenance notes, not archived reproducibility resources. They are not Lean imports. The recorded successful closure contains all project imports. The historical build scripts use fixed Windows paths and require adaptation for a fresh compilation. This README and its manifest are the only changes from v3.

/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily050
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily051
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily052
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily053
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily054
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily055
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily056
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily057
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily058
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalFamily059

#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL050
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL051
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL052
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL053
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL054
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL055
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL056
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL057
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL058
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL059

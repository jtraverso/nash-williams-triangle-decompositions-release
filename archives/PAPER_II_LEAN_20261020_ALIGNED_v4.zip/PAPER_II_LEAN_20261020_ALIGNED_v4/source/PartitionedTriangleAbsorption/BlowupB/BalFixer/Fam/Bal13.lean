/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal13Part1
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal13Part2
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal13Part3

#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL130
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL131
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL132
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL133
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL134
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL135
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL136
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL137
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL138
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL139

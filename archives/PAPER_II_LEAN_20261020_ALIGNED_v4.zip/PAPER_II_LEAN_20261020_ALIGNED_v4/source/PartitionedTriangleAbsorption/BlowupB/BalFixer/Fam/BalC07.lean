/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalC07Case042
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalC07Case043
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalC07Case044
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalC07Case045
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.BalC07Case047
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BALC042
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BALC043
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BALC044
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BALC045
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BALC047

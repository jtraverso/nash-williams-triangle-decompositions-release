/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal11Part1
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal11Part2
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal11Part3

#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL110
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL111
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL112
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL113
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL114
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL115
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL116
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL117
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL118
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL119

/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal28Part1
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal28Part2
import PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.Bal28Part3

#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL280
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL281
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL282
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL283
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL284
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL285
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL286
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL287
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL288
#print axioms PartitionedTriangleAbsorption.BlowupB.BalFixer.Fam.keevashTypedSpec_BAL289

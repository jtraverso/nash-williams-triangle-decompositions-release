/-
Copyright (c) 2026 Juan Pablo Traverso Gianini. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Juan Pablo Traverso Gianini
-/
import PartitionedTriangleAbsorption.BlowupB.Kappa.G3Closed
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed00
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed01
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed02
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed03
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed04
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed05
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed06
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed07
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed08
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed09
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed10
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed11
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed12
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed13
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed14
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed15
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed16
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed17
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed18
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed19
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed20
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed21
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed22
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed23
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed24
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed25
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed26
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed27
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed28
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed29
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed30
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed31
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed32
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed33
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed34
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed35
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed36
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed37
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed38
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed39
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed40
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed41
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed42
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed43
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed44
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed45
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed46
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed47
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed48
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed49
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed50
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed51
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed52
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed53
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed54
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed55
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed56
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed57
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed58
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed59
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed60
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed61
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed62
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed63
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed64
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed65
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed66
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed67
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed68
import PartitionedTriangleAbsorption.BlowupB.Flex.ParClosed.Closed69

/-! # `CoveredAll₁₂`: the 120 classes of `CoveredAll₁₁` and the PAR classes closed by vertex splitting -/

namespace PartitionedTriangleAbsorption.BlowupB

def CoveredAll₁₂ (F : Finset (Multiset (Fin 4))) : Prop :=
  CoveredAll₁₁ F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar00 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar01 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar02 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar03 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar04 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar05 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar06 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar07 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar08 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar09 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar10 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar11 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar12 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar13 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar14 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar15 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar16 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar17 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar18 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar19 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar20 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar21 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar22 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar23 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar24 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar25 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar26 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar27 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar28 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar29 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar30 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar31 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar32 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar33 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar34 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar35 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar36 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar37 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar38 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar39 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar40 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar41 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar42 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar43 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar44 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar45 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar46 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar47 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar48 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar49 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar50 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar51 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar52 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar53 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar54 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar55 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar56 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar57 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar58 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar59 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar60 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar61 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar62 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar63 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar64 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar65 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar66 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar67 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar68 F ∨ PartitionedTriangleAbsorption.BlowupB.Flex.Par.CoveredPar69 F

theorem keevashPaddedSpec_of_coveredAll₁₂ (F : Finset (Multiset (Fin 4))) (hF : CoveredAll₁₂ F) :
    PaddedInputs.KeevashPaddedSpec F := by
  rcases hF with hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF | hF
  · exact keevashPaddedSpec_of_coveredAll₁₁ F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar00 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar01 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar02 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar03 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar04 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar05 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar06 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar07 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar08 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar09 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar10 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar11 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar12 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar13 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar14 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar15 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar16 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar17 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar18 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar19 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar20 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar21 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar22 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar23 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar24 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar25 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar26 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar27 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar28 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar29 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar30 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar31 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar32 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar33 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar34 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar35 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar36 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar37 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar38 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar39 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar40 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar41 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar42 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar43 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar44 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar45 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar46 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar47 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar48 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar49 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar50 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar51 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar52 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar53 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar54 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar55 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar56 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar57 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar58 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar59 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar60 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar61 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar62 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar63 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar64 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar65 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar66 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar67 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar68 F hF
  · exact PartitionedTriangleAbsorption.BlowupB.Flex.Par.keevashPaddedSpec_of_coveredPar69 F hF

/-- The proved fragment of `TeoremaBTarget.TargetFour` with the PAR classes. -/
theorem targetFour_on_coveredAll₁₂ :
    ∀ F : Finset (Multiset (Fin 4)), PaddedGeneral.FamilyFacts F → CoveredAll₁₂ F →
      PaddedInputs.KeevashPaddedSpec F :=
  fun F _ hF => keevashPaddedSpec_of_coveredAll₁₂ F hF

end PartitionedTriangleAbsorption.BlowupB

#print axioms PartitionedTriangleAbsorption.BlowupB.targetFour_on_coveredAll₁₂

# Paper II: aligned clean build, freeze v1

Identifier: `PAPER_II_LEAN_20261020_ALIGNED_v1` (assembled 2026-10-20 11:37 UTC).

This freeze records a complete compilation of the Paper II closure from source. All 1510
project modules in the import closure of the three entry modules were compiled by the pinned toolchain
during one build campaign that started from an empty project output directory; no project object from
an earlier build was reused. The entry modules report 15 axiom queries, each listing
only `propext`, `Classical.choice` and `Quot.sound`. No module log contains a `sorry` warning.

Entry modules: `PartitionedTriangleAbsorption.PaperII.Core`, `PartitionedTriangleAbsorption.PaperII.Families`, `PartitionedTriangleAbsorption.PaperII.PaperIApplications`.

## What was built

- **Sources:** the aligned tree described in `evidence/ALIGNMENT_MANIFEST.json`, built from
  `PAPER_I_LEAN_20261017_v1` and `PAPER_II_LEAN_20261019_v1`. Shared modules take the Paper II freeze
  source. `RequestProject.NW18.FourColourPaperII` is moved unchanged to
  `PartitionedTriangleAbsorption.PaperII.FourColourApplication`, and `PaperIApplications` queries
  `NashWilliams18.PaperII.margin_four_colour_decomposition`, the declaration used by Paper I, instead
  of the former `FourColourConsumerStage84` consumer.
- **Toolchain and dependencies:** `leanprover/lean4:v4.35.0-rc3`; Mathlib `c55e6e786f49471c72fbddbec5415808896aec1e`;
  other revisions in `evidence/environment.json`. Mathlib objects were the pinned build products, not rebuilt.
- **Closure:** 1510 modules (the original Paper II freeze had 1,511). 623 of them
  are shared with Paper I and were compiled in the Paper I phase of the same campaign; the other
  887 were compiled in the Paper II phase.

## Evidence

| File | Content |
|---|---|
| `evidence/receipts/` | One receipt per module: exit code, seconds, source hash, project-import object hashes at compile time, own object hash; later receipts also record the Lean flags |
| `evidence/module_logs/` | Compiler output per module, including all `#print axioms` lines |
| `evidence/entry_audit.log` | Output of the three entry modules |
| `evidence/verification.json` | Checks run when this freeze was assembled, including the entry axiom queries |
| `evidence/build_plan.json` | Entry modules, topological order and project imports |
| `evidence/early_module_recheck.txt` | Recompilation of the first 23 modules after the Mathlib checkout changed |

At assembly every receipt succeeded, every source hash equalled the frozen source, every object on
disk had its recorded hash, and every recorded import hash equalled that import's own object hash.

## Limits

- The campaign ran in several invocations of `tools/build.py`, resumed after resource tuning; a
  resumed invocation accepted only objects whose receipts this campaign wrote and whose hashes matched.
- Lean's memory threshold (`-M`) was raised for the resumed Paper II pass: some `BalFixer` family
  modules exceed 5 GB and stopped with `memory_exception`. The threshold limits resources only; it does
  not change proofs. 517 receipts record a raised threshold.
- The first 23 modules were compiled against a separately downloaded Mathlib checkout of the same
  revision; their recompilation against the final checkout gave identical bytes (see evidence).
- Local build on one machine; not an independent reproduction. Compiled objects are not in the archive.

## Reproduction

`tools/align.py` rebuilds the aligned tree from the two source freezes; `tools/build.py paper_I` and
then `tools/build.py paper_II` recompile in topological order and write receipts and logs. The scripts
use fixed Windows workspace paths and must be adapted; provide Mathlib at the pinned revision.

# Author attribution and licences — selected Paper I sources

Copyright (c) 2026 Juan Pablo Traverso Gianini.

The author's project code and original packaging materials use Apache-2.0,
provided in `source/LICENSE` and `LICENSE`. All 1,070 project Lean headers
identify Juan Pablo Traverso Gianini. Aristotle is a computational tool,
acknowledged in the manuscripts, not the listed author.

The nine dependency licence texts are retained byte for byte. Cli keeps
MIT; the other supplied texts retain Apache-2.0. Existing mathematical
citations and source-provenance comments remain unchanged. No third-party
dependency source has been relabelled.

This is `PAPER_I_LEAN_20261020_ALIGNED_v3`, a header-only source revision of `PAPER_I_LEAN_20261020_ALIGNED_v2`
(SHA-256 `c04ca7dd432322fa65eab196d58954252f8e0f377222bd57a6a0c94ee82e116e`). It preserves all existing proof-evidence bytes.
The source hashes have changed; historical receipts still describe the
original compiled bytes, reconstructed by `tools/verify_attribution.py`.
No new Lean build is asserted. Manuscripts are separate artifacts.
